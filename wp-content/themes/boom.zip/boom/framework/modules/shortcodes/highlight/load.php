<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/highlight/highlight.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/highlight/custom-styles/highlight.php';