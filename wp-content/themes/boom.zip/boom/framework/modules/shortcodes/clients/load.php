<?php
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/clients/clients.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/clients/client.php';
