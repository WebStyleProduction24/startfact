<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/dropcaps/dropcaps.php';