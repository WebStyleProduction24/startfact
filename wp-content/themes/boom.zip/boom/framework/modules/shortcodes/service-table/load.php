<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/service-table/service-table.php';