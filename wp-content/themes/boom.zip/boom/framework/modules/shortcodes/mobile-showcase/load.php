<?php

require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/mobile-showcase/mobile-showcase-holder.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/mobile-showcase/mobile-showcase-item.php';