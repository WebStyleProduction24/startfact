<?php
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/particles/particles.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/particles/particles-content.php';