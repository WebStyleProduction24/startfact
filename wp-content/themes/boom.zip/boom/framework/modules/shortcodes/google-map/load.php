<?php
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/google-map/google-map.php';

