<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/team/team.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/team/custom-styles/team.php';