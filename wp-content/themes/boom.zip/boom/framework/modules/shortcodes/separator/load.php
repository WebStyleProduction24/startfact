<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/separator/separator.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/separator/custom-styles/separator.php';

