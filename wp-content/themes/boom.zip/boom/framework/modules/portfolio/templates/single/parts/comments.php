<?php if(qode_startit_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>
