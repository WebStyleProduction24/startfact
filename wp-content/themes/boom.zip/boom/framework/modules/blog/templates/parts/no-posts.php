<div class="entry">
	<p><?php esc_html_e('Не найдено!', 'startit'); ?></p>
</div>